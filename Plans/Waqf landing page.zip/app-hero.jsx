const {
  ICodeBrackets, IGitCommit, IGitPullRequest, IGitMerge, IGitBranch,
  IStar, IHeart, IHeartFilled, IArrowRight, ICheck, ICheckCircle,
  ISearch, IGlobe, IBookOpen, IHandHeart, IGradCap, IPiggy,
  IZap, IUsers, IFolderGit, IGithub, ITwitter, IDiscord,
  ISparkles, IShield, IShieldOutline, IBookmark, IPlus, IClock, IMail, IMosque,
} = window.WaqfIcons;

/* ============ NAVBAR ============ */
function Navbar({ lang, setLang }) {
  const isAr = lang === 'ar';
  const links = isAr
    ? ['الرئيسية', 'استكشف', 'كيف تعمل', 'مدوّنة', 'وثائق']
    : ['Home', 'Explore', 'How It Works', 'Blog', 'Docs'];
  return (
    <header className="nav">
      <div className="wrap nav__inner">
        <a className="logo" href="#" aria-label="Waqf">
          <span className="logo__mark"><IShield size={22} /></span>
          <span className="logo__txt">
            <span className="logo__name">{isAr ? 'وقف' : 'Waqf'}</span>
            <span className="logo__eye">{isAr ? 'مفتوح المصدر' : 'Open Source'}</span>
          </span>
        </a>
        <nav className="nav__links">
          {links.map((l, i) => (
            <a key={i} href="#" className="nav__link">{l}</a>
          ))}
        </nav>
        <div className="nav__actions">
          <button className="nav__lang" onClick={() => setLang(isAr ? 'en' : 'ar')}>
            <IGlobe size={14} /> {isAr ? 'EN' : 'عربي'}
          </button>
          <a className="btn btn--secondary btn--sm nav__github" href="#">
            <IGithub size={16} /> {isAr ? 'جيتهب' : 'GitHub'}
          </a>
          <a className="btn btn--primary btn--sm" href="#">
            {isAr ? 'ابدأ' : 'Sign In'} <IArrowRight size={14} />
          </a>
        </div>
      </div>
    </header>
  );
}

/* ============ HERO ============ */
function Hero({ lang, variant }) {
  const isAr = lang === 'ar';
  return (
    <section className="hero">
      <div className="wrap hero__grid">
        <div>
          <div className="hero__eye">
            <span className="hero__eye-line"></span>
            <span className="eyebrow">{isAr ? 'وقف · مفتوح المصدر' : 'Waqf · Open Source'}</span>
            <span className="pill pill--accent">
              <IZap size={11} fill="currentColor" stroke="none" />
              {isAr ? 'نسخة تجريبية' : 'Beta Live'}
            </span>
          </div>

          <h1 className="hero__title">
            {isAr ? (
              <>
                <span className="hero__title-en">صدقة جارية</span>
                <span className="hero__title-ar"><em className="hero__title-em">عبر الكود</em></span>
              </>
            ) : (
              <>
                <span className="hero__title-en">Code that earns <em className="hero__title-em">forever.</em></span>
                <span className="hero__title-ar">صدقة جارية عبر الكود</span>
              </>
            )}
          </h1>

          <p className="hero__lede">
            {isAr
              ? 'انضم إلى أول مجتمع مفتوح المصدر يبني التقنية للأمة. ساهم بمهاراتك في مشاريع تنفع الملايين — والتزاماتك تصبح صدقة جارية.'
              : 'Join the first open-source community building tech for the Muslim Ummah. Contribute your skills to projects that serve millions — every commit becomes Sadaqah Jariyah.'}
          </p>

          <div className="hero__ctas">
            <a className="btn btn--primary btn--lg" href="#">
              <ICodeBrackets size={18} />
              {isAr ? 'ابدأ المساهمة' : 'Start Contributing'}
            </a>
            <a className="btn btn--secondary btn--lg" href="#">
              <IPlus size={18} />
              {isAr ? 'أضف مشروعاً' : 'List a Project'}
            </a>
          </div>

          <div className="hero__proof">
            <div className="hero__proof-avatars">
              <span style={{ background: 'rgba(31,112,93,0.15)', color: 'var(--primary-700)' }}>AY</span>
              <span style={{ background: 'rgba(212,160,86,0.18)', color: 'var(--accent-600)' }}>MK</span>
              <span style={{ background: '#dbeafe', color: '#1d4ed8' }}>SR</span>
              <span style={{ background: 'rgba(31,112,93,0.10)', color: 'var(--primary-700)' }}>+2k</span>
            </div>
            <div className="hero__proof-meta">
              <span><IUsers size={14} /> {isAr ? '+2,184 مساهم' : '2,184 contributors'}</span>
              <span><IGlobe size={14} /> {isAr ? '47 دولة' : '47 countries'}</span>
            </div>
          </div>
        </div>

        <div className="hero__visual">
          {variant === 'snippet' && <HeroSnippet isAr={isAr} />}
          {variant === 'callig' && <HeroCallig isAr={isAr} />}
          {(!variant || variant === 'feed') && <HeroFeed isAr={isAr} />}
        </div>
      </div>
    </section>
  );
}

/* ============ HERO VARIANT: live feed ============ */
function HeroFeed({ isAr }) {
  const seed = React.useMemo(() => ([
    { who: 'Ahmed Y.', avatar: 'A', color: '#1f705d', action: 'merged', verb: isAr ? 'دمج' : 'merged', what: 'translation/ar-fix', repo: 'quran-api', when: isAr ? 'الآن' : 'just now', icon: <IGitMerge size={12} /> },
    { who: 'Maryam K.', avatar: 'M', color: '#d4a056', action: 'opened',  verb: isAr ? 'فتح'  : 'opened',  what: 'feat: hijri picker', repo: 'salah-times', when: isAr ? 'منذ دقيقة' : '1 min ago', icon: <IGitPullRequest size={12} /> },
    { who: 'Saif R.',   avatar: 'S', color: '#2563eb', action: 'pushed',  verb: isAr ? 'دفع'  : 'pushed',  what: '3 commits', repo: 'zakat-calc', when: isAr ? 'منذ 4 دقائق' : '4 min ago', icon: <IGitCommit size={12} /> },
    { who: 'Layla H.',  avatar: 'L', color: '#059669', action: 'released', verb: isAr ? 'أصدر' : 'released', what: 'v2.1 adhkar app', repo: 'daily-adhkar', when: isAr ? 'منذ 8 دقائق' : '8 min ago', icon: <ISparkles size={12} /> },
  ]), [isAr]);

  const [items, setItems] = React.useState(seed);
  const [hasanat, setHasanat] = React.useState(38420);

  React.useEffect(() => {
    let timer;
    const samples = [
      { who: 'Yusuf A.', avatar: 'Y', color: '#1f705d', verb: isAr ? 'دفع' : 'pushed', what: '2 commits', repo: 'quran-api', icon: <IGitCommit size={12} /> },
      { who: 'Hassan B.', avatar: 'H', color: '#d4a056', verb: isAr ? 'دمج' : 'merged', what: 'fix: prayer offset', repo: 'salah-times', icon: <IGitMerge size={12} /> },
      { who: 'Aisha N.', avatar: 'A', color: '#2563eb', verb: isAr ? 'فتح' : 'opened', what: 'feat: night mode', repo: 'daily-adhkar', icon: <IGitPullRequest size={12} /> },
      { who: 'Omar D.', avatar: 'O', color: '#059669', verb: isAr ? 'دفع' : 'pushed', what: '5 commits', repo: 'halal-finance-sdk', icon: <IGitCommit size={12} /> },
      { who: 'Zaynab T.', avatar: 'Z', color: '#1f705d', verb: isAr ? 'دمج' : 'merged', what: 'docs(ar)', repo: 'sunnah-md', icon: <IGitMerge size={12} /> },
    ];
    let i = 0;
    const tick = () => {
      const s = samples[i % samples.length];
      i += 1;
      setItems((arr) => [{ ...s, when: isAr ? 'الآن' : 'just now', isNew: true }, ...arr.slice(0, 3).map(x => ({ ...x, isNew: false, when: bumpTime(x.when, isAr) }))]);
      setHasanat((h) => h + Math.floor(2 + Math.random() * 8));
      timer = setTimeout(tick, 3200 + Math.random() * 2000);
    };
    timer = setTimeout(tick, 3000);
    return () => clearTimeout(timer);
  }, [isAr]);

  return (
    <div style={{ position: 'relative' }}>
      <div className="float-chip float-chip--tl">
        <IFolderGit size={14} />
        <span>147 {isAr ? 'مشروع نشط' : 'active repos'}</span>
      </div>

      <div className="feed">
        <div className="feed__head">
          <span className="feed__title">{isAr ? <>نشاط <b>المجتمع</b></> : <>community <b>activity</b></>}</span>
          <span className="feed__live"><span className="pill__dot pill__dot--live"></span>{isAr ? 'مباشر' : 'Live'}</span>
        </div>
        <div className="feed__list">
          {items.slice(0, 4).map((it, idx) => (
            <div key={`${it.who}-${idx}-${it.when}`} className={`feed__row${it.isNew ? ' is-new' : ''}`}>
              <span className="feed__avatar" style={{ background: it.color }}>{it.avatar}</span>
              <div className="feed__body">
                <div className="feed__line">
                  <b>{it.who}</b> {it.verb} <span className="repo force-latin">{it.what}</span>
                </div>
                <div className="feed__meta">
                  <span className="force-latin">{it.icon}&nbsp;{it.repo}</span>
                  <span className="dot"></span>
                  <span>{it.when}</span>
                </div>
              </div>
              <span className="feed__action force-latin">+{3 + (idx * 2)}H</span>
            </div>
          ))}
        </div>
        <div className="feed__hasanat">
          <div>
            <div className="feed__hasanat-l">{isAr ? 'حسنات اليوم' : "Today's Hasanat"}</div>
            <div className="feed__hasanat-n force-latin">
              {hasanat.toLocaleString('en-US')}
              <span className="delta">+{((hasanat - 38420) || 1)}</span>
            </div>
          </div>
          <span className="feed__hasanat-icon"><IHeartFilled size={18} /></span>
        </div>
      </div>

      <div className="float-chip float-chip--br float-chip--accent">
        <IHeartFilled size={14} />
        <div>
          <span>{isAr ? '1.2M مستخدم' : '1.2M users reached'}</span>
          <div className="sm">{isAr ? 'هذا الشهر' : 'this month'}</div>
        </div>
      </div>
    </div>
  );
}

function bumpTime(t, isAr) {
  if (isAr) {
    if (t === 'الآن') return 'منذ دقيقة';
    if (t === 'منذ دقيقة') return 'منذ 4 دقائق';
    if (t === 'منذ 4 دقائق') return 'منذ 8 دقائق';
    return 'منذ 12 دقيقة';
  }
  if (t === 'just now') return '1 min ago';
  if (t === '1 min ago') return '4 min ago';
  if (t === '4 min ago') return '8 min ago';
  return '12 min ago';
}

function HeroSnippet({ isAr }) {
  return (
    <div style={{ position: 'relative' }}>
      <div className="snippet">
        <div className="snippet__bar">
          <div className="snippet__dots">
            <span style={{ background: '#f87171' }}></span>
            <span style={{ background: '#fbbf24' }}></span>
            <span style={{ background: '#4ade80' }}></span>
          </div>
          <span className="snippet__file">contribute.js</span>
        </div>
        <div>
          <span className="kw">const</span> <span className="fn">sadaqah</span> <span className="pn">=</span> <span className="yl">async</span> <span className="pn">{'() => {'}</span>
        </div>
        <div className="indent">
          <span className="kw">await</span> <span className="fn">buildForUmmah</span><span className="pn">();</span>
        </div>
        <div className="indent">
          <span className="kw">return</span> <span className="str">"Hasanat++"</span><span className="pn">;</span>
        </div>
        <div><span className="pn">{'}'}</span></div>
      </div>
      <div className="float-chip float-chip--br float-chip--accent">
        <IHeartFilled size={14} />
        <span>{isAr ? '1.2M مستخدم' : '1.2M reached'}</span>
      </div>
    </div>
  );
}

function HeroCallig({ isAr }) {
  return (
    <div className="callig">
      <div className="callig__bg"></div>
      <div className="callig__shield"><IShield size={44} /></div>
      <div className="callig__ar">وقف</div>
      <div className="callig__en">{isAr ? 'وقف · مفتوح المصدر' : 'A waqf in code'}</div>
    </div>
  );
}

window.Navbar = Navbar;
window.Hero = Hero;
