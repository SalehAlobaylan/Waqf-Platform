/* Main app — composes the landing page + Tweaks panel */
const { useState, useEffect, useMemo } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "lang": "en",
  "accent": "#1f705d",
  "density": "regular",
  "heroVariant": "feed"
}/*EDITMODE-END*/;

const ACCENT_PRESETS = {
  '#1f705d': { deep: '#165244', tint: 'rgba(31,112,93,0.08)',  line: 'rgba(31,112,93,0.18)'  }, // waqf green
  '#0f766e': { deep: '#0a5d56', tint: 'rgba(15,118,110,0.08)', line: 'rgba(15,118,110,0.18)' }, // teal
  '#134a3d': { deep: '#0e3a30', tint: 'rgba(19,74,61,0.08)',   line: 'rgba(19,74,61,0.18)'   }, // deep forest
  '#0f4c81': { deep: '#0a3a63', tint: 'rgba(15,76,129,0.08)',  line: 'rgba(15,76,129,0.18)'  }, // ink blue
};

function applyTheme({ lang, accent, density }) {
  const root = document.documentElement;
  root.setAttribute('dir', lang === 'ar' ? 'rtl' : 'ltr');
  root.setAttribute('lang', lang);
  root.setAttribute('data-density', density);
  const p = ACCENT_PRESETS[accent] || ACCENT_PRESETS['#1f705d'];
  root.style.setProperty('--accent-h', accent);
  root.style.setProperty('--accent-h-deep', p.deep);
  root.style.setProperty('--accent-h-tint', p.tint);
  root.style.setProperty('--accent-h-line', p.line);
}

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  useEffect(() => {
    applyTheme(t);
  }, [t.lang, t.accent, t.density]);

  // Allow Navbar's button to flip lang AND persist via Tweaks
  const setLang = (l) => setTweak('lang', l);

  return (
    <>
      <Navbar lang={t.lang} setLang={setLang} />
      <main>
        <Hero lang={t.lang} variant={t.heroVariant} />
        <Ticker lang={t.lang} />
        <Stats lang={t.lang} />
        <Mission lang={t.lang} />
        <HowItWorks lang={t.lang} />
        <FeaturedProjects lang={t.lang} />
        <Categories lang={t.lang} />
        <DualPath lang={t.lang} />
        <Voices lang={t.lang} />
        <CtaBlock lang={t.lang} />
      </main>
      <Footer lang={t.lang} />

      <TweaksPanel>
        <TweakSection label="Language" />
        <TweakRadio
          label="Direction"
          value={t.lang}
          options={[
            { value: 'en', label: 'English' },
            { value: 'ar', label: 'عربي' },
          ]}
          onChange={(v) => setTweak('lang', v)}
        />

        <TweakSection label="Hero visual" />
        <TweakSelect
          label="Variant"
          value={t.heroVariant}
          options={[
            { value: 'feed',    label: 'Live activity feed' },
            { value: 'snippet', label: 'Rotated code card' },
            { value: 'callig',  label: 'Arabic calligraphy' },
          ]}
          onChange={(v) => setTweak('heroVariant', v)}
        />

        <TweakSection label="Theme" />
        <TweakColor
          label="Accent"
          value={t.accent}
          options={['#1f705d', '#0f766e', '#134a3d', '#0f4c81']}
          onChange={(v) => setTweak('accent', v)}
        />
        <TweakRadio
          label="Density"
          value={t.density}
          options={[
            { value: 'compact',  label: 'Compact'  },
            { value: 'regular',  label: 'Regular'  },
            { value: 'spacious', label: 'Spacious' },
          ]}
          onChange={(v) => setTweak('density', v)}
        />
      </TweaksPanel>
    </>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
