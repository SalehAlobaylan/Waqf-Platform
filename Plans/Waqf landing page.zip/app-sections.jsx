const {
  ICodeBrackets: H_ICodeBrackets, IGitCommit: H_IGitCommit, IGitPullRequest: H_IGitPullRequest,
  IGitMerge: H_IGitMerge, IGitBranch: H_IGitBranch,
  IStar: H_IStar, IHeart: H_IHeart, IHeartFilled: H_IHeartFilled,
  IArrowRight: H_IArrowRight, ICheck: H_ICheck, ICheckCircle: H_ICheckCircle,
  ISearch: H_ISearch, IGlobe: H_IGlobe, IBookOpen: H_IBookOpen,
  IHandHeart: H_IHandHeart, IGradCap: H_IGradCap, IPiggy: H_IPiggy,
  IZap: H_IZap, IUsers: H_IUsers, IFolderGit: H_IFolderGit,
  IGithub: H_IGithub, ITwitter: H_ITwitter, IDiscord: H_IDiscord,
  ISparkles: H_ISparkles, IShield: H_IShield, IShieldOutline: H_IShieldOutline,
  IBookmark: H_IBookmark, IPlus: H_IPlus, IClock: H_IClock, IMail: H_IMail, IMosque: H_IMosque,
} = window.WaqfIcons;

/* ============ TICKER (between hero and stats) ============ */
function Ticker({ lang }) {
  const isAr = lang === 'ar';
  const items = isAr
    ? [
        ['+38,420', 'التزام'],
        ['147', 'مشروع'],
        ['2,184', 'مساهم'],
        ['47', 'دولة'],
        ['12', 'لغة'],
        ['0', 'رسوم على المشاريع'],
      ]
    : [
        ['+38,420', 'commits this month'],
        ['147', 'active projects'],
        ['2,184', 'contributors'],
        ['47', 'countries'],
        ['12', 'languages'],
        ['0%', 'platform fees'],
      ];
  // duplicate for seamless loop
  const loop = [...items, ...items];
  return (
    <div className="ticker">
      <div className="ticker__track">
        {loop.map((it, i) => (
          <div key={i} className="ticker__item">
            <H_ISparkles size={14} />
            <b className="force-latin">{it[0]}</b>
            <span>{it[1]}</span>
            <span className="sep"></span>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ============ STATS ============ */
function Stats({ lang }) {
  const isAr = lang === 'ar';
  const data = [
    { num: '2,184', unit: '+', lbl: isAr ? 'مساهم نشط' : 'Active contributors', icon: <H_IUsers size={18} /> },
    { num: '147',  unit: '', lbl: isAr ? 'مشروع مفتوح المصدر' : 'Open-source projects', icon: <H_IFolderGit size={18} /> },
    { num: '38.4', unit: 'K', lbl: isAr ? 'التزام هذا الشهر' : 'Commits this month', icon: <H_IGitCommit size={18} /> },
    { num: '0',    unit: '%', lbl: isAr ? 'رسوم على المنصة' : 'Platform fees, forever', icon: <H_IHeart size={18} /> },
  ];
  return (
    <section className="stats">
      <div className="wrap">
        <div className="stats__grid">
          {data.map((s, i) => (
            <div key={i} className="stats__cell">
              <div className="stats__num force-latin">
                {s.num}<span className="unit">{s.unit}</span>
              </div>
              <div className="stats__lbl">{s.lbl}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ============ MISSION QUOTE ============ */
function Mission({ lang }) {
  const isAr = lang === 'ar';
  return (
    <section className="mission">
      <div className="mission__wrap">
        <span className="mission__eye">{isAr ? 'مهمتنا' : 'Our Mission'}</span>
        <div className="mission__ar">إِذَا مَاتَ ابْنُ آدَمَ انْقَطَعَ عَمَلُهُ إِلَّا مِنْ ثَلَاثٍ</div>
        <p className="mission__en">
          {isAr
            ? <>"إذا مات ابن آدم انقطع عمله إلا من ثلاث: صدقة جارية، أو علم ينتفع به، أو ولد صالح يدعو له." — <em>الكود الذي تُسهم به اليوم يصبح صدقتك الجارية غدًا.</em></>
            : <>"When a person dies, their deeds end except three: a continuous charity, knowledge that benefits, or a righteous child who prays for them." — <em>The code you ship today becomes your Sadaqah Jariyah tomorrow.</em></>
          }
        </p>
        <div className="mission__attrib">— Sahih Muslim · 1631</div>
      </div>
    </section>
  );
}

/* ============ HOW IT WORKS ============ */
function HowItWorks({ lang }) {
  const isAr = lang === 'ar';
  const steps = [
    {
      icon: <H_ISearch />,
      title: isAr ? 'اكتشف' : 'Discover',
      titleAr: 'اكتشف',
      desc: isAr
        ? 'تصفّح المشاريع الإسلامية مفتوحة المصدر التي تتطابق مع مهاراتك واهتماماتك.'
        : 'Browse Islamic open-source projects matched to your skills, language, and faith.',
    },
    {
      icon: <H_ICodeBrackets />,
      title: isAr ? 'ساهم' : 'Contribute',
      titleAr: 'ساهم',
      desc: isAr
        ? 'تقدّم بطلبك، تطابق مع المنشئ، وادفع الكود الذي يخدم الملايين من المسلمين.'
        : 'Apply, get matched with the maintainer, and ship code that serves millions of Muslims worldwide.',
    },
    {
      icon: <H_IHeartFilled />,
      title: isAr ? 'اكسب الحسنات' : 'Earn Hasanat',
      titleAr: 'اكسب الحسنات',
      desc: isAr
        ? 'كل التزام يصبح صدقة جارية. أجرك يتجدد طالما الكود ينفع الأمة.'
        : 'Every commit becomes Sadaqah Jariyah. Your reward continues as long as the code serves the Ummah.',
      reward: true,
    },
  ];
  return (
    <section className="section section--tint">
      <div className="wrap">
        <div className="section__head section__head--center">
          <span className="eyebrow">{isAr ? 'كيف يعمل' : 'How It Works'}</span>
          <h2 className="section__title">
            {isAr ? (<>ثلاث خطوات. <em>أجر دائم.</em></>) : (<>Three steps. <em>Reward that lasts.</em></>)}
          </h2>
          <p className="section__sub" style={{ marginInline: 'auto' }}>
            {isAr
              ? 'الإسهام في وقف ليس مجرد كود. هو عبادة، وفي رواية: "الدالّ على الخير كفاعله".'
              : "Contributing on Waqf isn't just code — it's an act of worship. Every line earns reward for as long as it helps."}
          </p>
        </div>

        <div className="steps">
          {steps.map((s, i) => (
            <article key={i} className={`step${s.reward ? ' step--reward' : ''}`}>
              <span className="step__num force-latin">0{i + 1}</span>
              <div className="step__icon">{s.icon}</div>
              <h3 className="step__title">
                {s.title}
                {!isAr && <span className="ar">{s.titleAr}</span>}
              </h3>
              <p className="step__desc">{s.desc}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ============ FEATURED PROJECTS ============ */
function FeaturedProjects({ lang }) {
  const isAr = lang === 'ar';
  const projects = [
    {
      tag: isAr ? 'القرآن والسنة' : 'Quran & Sunnah',
      initial: 'Q', org: 'Tarteel.ai',
      title: isAr ? 'واجهة برمجة القرآن الكريم' : 'Open Quran API',
      desc: isAr
        ? 'API موحّد لخمس عشرة ترجمة + التلاوات. يستخدمه أكثر من 200 تطبيق.'
        : 'A unified API serving 15 translations + recitations. Powering 200+ apps worldwide.',
      skills: [['py', 'Python'], ['ts', 'TypeScript'], ['go', 'Go']],
      stars: 4823, openRoles: 7, cover: '',
    },
    {
      tag: isAr ? 'الزكاة والخير' : 'Charity & Zakat', cover: 'accent',
      initial: 'Z', org: 'IslamicRelief',
      title: isAr ? 'حاسبة الزكاة v3' : 'Zakat Calculator v3',
      desc: isAr
        ? 'حاسبة شفافة متعددة المذاهب — تحوّل العملات الفورية ودعم الذهب والكريبتو.'
        : 'A transparent multi-madhhab calculator with live currency, gold spot, and crypto holdings.',
      skills: [['react', 'React'], ['ts', 'TypeScript'], ['rust', 'Rust']],
      stars: 1240, openRoles: 4,
    },
    {
      tag: isAr ? 'تعليم إسلامي' : 'EdTech', cover: 'blue',
      initial: 'A', org: 'Madrasah.dev',
      title: isAr ? 'تطبيق الأذكار اليومية' : 'Daily Adhkar Companion',
      desc: isAr
        ? 'تطبيق أذكار غير متصل بـ 12 لغة، مع تنبيهات ذكية حسب أوقات الصلاة.'
        : 'Offline-first adhkar in 12 languages, with smart reminders tied to local prayer times.',
      skills: [['flutter', 'Flutter'], ['py', 'Python']],
      stars: 892, openRoles: 3,
    },
  ];
  return (
    <section className="section">
      <div className="wrap">
        <div className="section__head section__head--row">
          <div>
            <span className="eyebrow">{isAr ? 'مشاريع مميّزة' : 'Featured Projects'}</span>
            <h2 className="section__title">
              {isAr ? <>ابنِ ما <em>يستمر</em><span className="ar">يستمر</span></> : <>Ship things that <em>last.</em></>}
            </h2>
          </div>
          <a className="btn btn--secondary btn--md" href="#">
            {isAr ? 'استعرض الكل' : 'Explore all'} <H_IArrowRight size={14} />
          </a>
        </div>

        <div className="projects">
          {projects.map((p, i) => (
            <article key={i} className="pcard">
              <div className={`pcard__cover${p.cover ? ' pcard__cover--' + p.cover : ''}`}>
                <span className="pcard__cover-initial force-latin">{p.initial}</span>
                <span className={`pcard__cover-tag${p.cover === 'accent' ? ' pcard__cover-tag--accent' : ''}`}>
                  {p.tag}
                </span>
              </div>
              <div className="pcard__body">
                <div>
                  <h3 className="pcard__title">{p.title}</h3>
                  <p className="pcard__org">
                    <H_ICheckCircle size={12} /> {p.org}
                  </p>
                </div>
                <p className="pcard__desc">{p.desc}</p>
                <div className="pcard__skills">
                  {p.skills.map((s, j) => (
                    <span key={j} className={`skill skill--${s[0]} force-latin`}>{s[1]}</span>
                  ))}
                </div>
              </div>
              <div className="pcard__foot">
                <span className="pcard__open">{p.openRoles} {isAr ? 'دور مفتوح' : 'open roles'}</span>
                <span className="pcard__foot-stat force-latin">
                  <H_IStar size={12} /> {p.stars.toLocaleString('en-US')}
                </span>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ============ CATEGORIES ============ */
function Categories({ lang }) {
  const isAr = lang === 'ar';
  const cats = [
    { icon: <H_IBookOpen />, title: isAr ? 'القرآن والسنة' : 'Quran & Sunnah',
      titleAr: 'القرآن والسنة',
      desc: isAr ? 'تطبيقات التلاوة، التراجم، وأدوات حفظ الحديث.' : 'Recitation apps, translations, and tools for hadith study.',
      count: '42', color: 'var(--cat-quran)' },
    { icon: <H_IHandHeart />, title: isAr ? 'الزكاة والصدقة' : 'Charity & Zakat',
      titleAr: 'الزكاة والصدقة',
      desc: isAr ? 'حاسبات، منصات تبرع، وأدوات المنظمات الخيرية.' : 'Calculators, giving platforms, and tools for non-profits.',
      count: '28', color: 'var(--cat-charity)' },
    { icon: <H_IGradCap />, title: isAr ? 'تعليم إسلامي' : 'Islamic EdTech',
      titleAr: 'تعليم إسلامي',
      desc: isAr ? 'منصات تعليم تفاعلية، الفقه، والعربية للناطقين بغيرها.' : 'Interactive learning, fiqh, and Arabic-as-a-second-language.',
      count: '34', color: 'var(--cat-edtech)' },
    { icon: <H_IPiggy />, title: isAr ? 'تمويل حلال' : 'Halal Finance',
      titleAr: 'تمويل حلال',
      desc: isAr ? 'بنوك مفتوحة المصدر، أدوات استثمار شرعي ومعاينة الأسهم.' : 'Open banking, shariah screeners, and ethical investing tools.',
      count: '19', color: 'var(--cat-finance)' },
  ];
  return (
    <section className="section">
      <div className="wrap">
        <div className="section__head">
          <span className="eyebrow">{isAr ? 'المجالات' : 'Domains'}</span>
          <h2 className="section__title">
            {isAr ? <>أربعة طرق <em>للأمة.</em></> : <>Four paths. <em>One Ummah.</em></>}
          </h2>
          <p className="section__sub">
            {isAr
              ? 'كل مشروع في وقف يندرج تحت أحد المجالات الأربعة — اختر الذي يلامس مهاراتك.'
              : 'Every Waqf project lives in one of four domains. Pick the one that calls to your skills — or browse them all.'}
          </p>
        </div>

        <div className="cats">
          {cats.map((c, i) => (
            <a key={i} className="cat" href="#" style={{ '--cat-color': c.color }}>
              <div className="cat__icon">{c.icon}</div>
              <h3 className="cat__title">
                {c.title}
                {!isAr && <span className="ar">{c.titleAr}</span>}
              </h3>
              <p className="cat__desc">{c.desc}</p>
              <span className="cat__count force-latin">{c.count} {isAr ? 'مشروع' : 'projects'}</span>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ============ DUAL PATH ============ */
function DualPath({ lang }) {
  const isAr = lang === 'ar';
  return (
    <section className="section section--tint">
      <div className="wrap">
        <div className="section__head section__head--center">
          <span className="eyebrow">{isAr ? 'طريقان' : 'Two Paths'}</span>
          <h2 className="section__title">
            {isAr ? <>اختر دورك. <em>ابدأ اليوم.</em></> : <>Pick your path. <em>Start today.</em></>}
          </h2>
        </div>

        <div className="paths">
          <article className="path path--contributor">
            <span className="path__eye">{isAr ? 'للمساهم' : 'For Contributors'}</span>
            <h3 className="path__title">
              {isAr ? 'حوّل كودك إلى صدقة.' : 'Turn your code into Sadaqah.'}
              <span className="ar">{isAr ? 'مساهم' : 'مساهم'}</span>
            </h3>
            <p className="path__desc">
              {isAr
                ? 'اعثر على مشاريع تتطابق مع مهاراتك واسهم بأوقاتك الفائضة.'
                : 'Find projects matched to your stack and contribute on your own schedule.'}
            </p>
            <ul className="path__list">
              <li><H_ICheck size={18} /> <span><b>{isAr ? 'تطابق ذكي.' : 'Smart matching.'}</b> {isAr ? 'وفقاً للغتك، خبرتك، ووقتك.' : 'By language, stack, and weekly hours.'}</span></li>
              <li><H_ICheck size={18} /> <span><b>{isAr ? 'مرشدون متاحون.' : 'Mentors on call.'}</b> {isAr ? 'مراجعات الكود من مهندسين كبار.' : 'Get reviews from senior engineers.'}</span></li>
              <li><H_ICheck size={18} /> <span><b>{isAr ? 'سجل الحسنات.' : 'Hasanat ledger.'}</b> {isAr ? 'تتبع أثر مساهماتك بمرور الوقت.' : 'Track the lasting impact of every commit.'}</span></li>
            </ul>
            <div className="path__foot">
              <a className="btn btn--primary btn--lg" href="#">
                <H_ICodeBrackets size={18} /> {isAr ? 'ابدأ المساهمة' : 'Start Contributing'}
              </a>
              <span className="path__meta">{isAr ? 'مجاناً، إلى الأبد.' : 'Free, forever.'}</span>
            </div>
          </article>

          <article className="path path--creator">
            <span className="path__eye">{isAr ? 'لمنشئ المشروع' : 'For Creators'}</span>
            <h3 className="path__title">
              {isAr ? 'استقطب فريقاً مؤمناً بمهمتك.' : 'Recruit a team that shares your mission.'}
              <span className="ar">{isAr ? 'منشئ' : 'منشئ'}</span>
            </h3>
            <p className="path__desc">
              {isAr
                ? 'انشر مشروعك، حدّد الأدوار، واترك المنصة تتطابق مع المساهمين المناسبين.'
                : 'List your project, define roles, and let Waqf match you with vetted, mission-aligned contributors.'}
            </p>
            <ul className="path__list">
              <li><H_ICheck size={18} /> <span><b>{isAr ? 'إدراج موثّق.' : 'Verified listing.'}</b> {isAr ? 'شارة لمنظمتك بعد التحقق.' : 'Earn the verified-org badge in 24h.'}</span></li>
              <li><H_ICheck size={18} /> <span><b>{isAr ? 'مرشّحون نوعيون.' : 'Quality applicants.'}</b> {isAr ? 'مساهمون مؤمنون بالقضية.' : 'Devs aligned with the why, not just the what.'}</span></li>
              <li><H_ICheck size={18} /> <span><b>{isAr ? 'بنية تحتية مدفوعة.' : 'Infra credits.'}</b> {isAr ? 'استضافة وأدوات مجانية للمشاريع المعتمدة.' : 'Free hosting + tooling for approved projects.'}</span></li>
            </ul>
            <div className="path__foot">
              <a className="btn btn--ondark-primary btn--lg" href="#">
                <H_IPlus size={18} /> {isAr ? 'أضف مشروعاً' : 'List a Project'}
              </a>
              <span className="path__meta">{isAr ? '24 ساعة للموافقة.' : 'Approved in 24h.'}</span>
            </div>
          </article>
        </div>
      </div>
    </section>
  );
}

/* ============ VOICES / TESTIMONIALS ============ */
function Voices({ lang }) {
  const isAr = lang === 'ar';
  const items = [
    {
      quote: isAr
        ? 'كنت أكتب كوداً للشركات لسنوات. أول التزام لي على وقف شعرت أنه ذو معنى — وبعد ستة أشهر، أنا أقود مشروع API القرآن.'
        : "I'd been writing code for corporations for years. My first commit on Waqf felt like the first that mattered. Six months in, I'm leading the Quran API project.",
      name: 'Ahmed Yusuf', role: isAr ? 'مهندس واجهة خلفية · لندن' : 'Backend Engineer · London',
      avatar: 'A', color: '#1f705d', stars: 5,
    },
    {
      quote: isAr
        ? 'كمنشئ لـ Madrasah.dev، استقطبنا فريقاً مكوّناً من 12 مطوّراً خلال أسبوعين. لا توجد منصة أخرى تستطيع ذلك.'
        : 'As a creator on Madrasah.dev, I built a team of 12 contributors in two weeks. No other platform could have done that.',
      name: 'Maryam Khan', role: isAr ? 'مؤسس Madrasah.dev · دبي' : 'Founder, Madrasah.dev · Dubai',
      avatar: 'M', color: '#d4a056', stars: 5,
    },
    {
      quote: isAr
        ? 'الكود الذي ساهمت به العام الماضي أصبح في يد مليون مستخدم. لا يوجد مقياس KPI يضاهي هذا الشعور.'
        : 'Code I shipped last year is now in the hands of a million users. No KPI dashboard hits like that.',
      name: 'Saif Rahman', role: isAr ? 'مطوّر تطبيقات الجوال · كوالا لمبور' : 'Mobile Engineer · Kuala Lumpur',
      avatar: 'S', color: '#2563eb', stars: 5,
    },
  ];
  return (
    <section className="section">
      <div className="wrap">
        <div className="section__head section__head--center">
          <span className="eyebrow">{isAr ? 'أصوات المجتمع' : 'Voices from the Ummah'}</span>
          <h2 className="section__title">
            {isAr ? <>قصص من <em>المساهمين.</em></> : <>Stories from <em>the contributors.</em></>}
          </h2>
        </div>

        <div className="voices">
          {items.map((v, i) => (
            <article key={i} className="voice">
              <div className="voice__stars">
                {Array.from({ length: v.stars }).map((_, j) => <H_IStar key={j} size={16} />)}
              </div>
              <p className="voice__quote">{v.quote}</p>
              <div className="voice__author">
                <span className="voice__avatar" style={{ background: v.color }}>{v.avatar}</span>
                <div>
                  <p className="voice__name">{v.name}</p>
                  <p className="voice__role">{v.role}</p>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ============ FINAL CTA ============ */
function CtaBlock({ lang }) {
  const isAr = lang === 'ar';
  return (
    <section className="cta-section">
      <div className="wrap">
        <div className="cta-box">
          <div className="cta-box__inner">
            <span className="cta-box__eye">{isAr ? 'جاهز للبدء؟' : 'Ready to begin?'}</span>
            <h2 className="cta-box__title">
              {isAr ? <>كوّد لقضية.<span className="ar">صدقة جارية</span></> : <>Code for a cause.<span className="ar">صدقة جارية عبر الكود</span></>}
            </h2>
            <p className="cta-box__desc">
              {isAr
                ? 'انضم إلى آلاف المطورين الذين يحولون التزاماتهم إلى صدقة جارية.'
                : 'Join thousands of developers turning their commits into Sadaqah Jariyah.'}
            </p>
            <div className="cta-box__btns">
              <a className="btn btn--ondark-primary btn--lg" href="#">
                <H_ICodeBrackets size={18} /> {isAr ? 'ابدأ المساهمة' : 'Start Contributing'}
              </a>
              <a className="btn btn--ondark-secondary btn--lg" href="#">
                <H_IPlus size={18} /> {isAr ? 'أضف مشروعاً' : 'List a Project'}
              </a>
            </div>
            <div className="cta-box__meta">
              <span><H_ICheck size={14} /> {isAr ? 'مجاناً، إلى الأبد' : 'Free, forever'}</span>
              <span><H_ICheck size={14} /> {isAr ? 'بدون رسوم' : 'Zero platform fees'}</span>
              <span><H_ICheck size={14} /> {isAr ? 'مفتوح المصدر بالكامل' : 'Fully open-source'}</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ============ FOOTER ============ */
function Footer({ lang }) {
  const isAr = lang === 'ar';
  const groups = [
    {
      title: isAr ? 'المنصة' : 'Platform',
      links: isAr ? ['استكشف', 'كيف تعمل', 'الأدوار', 'حسابي', 'لوحة التحكم'] : ['Explore', 'How It Works', 'Roles', 'Profile', 'Dashboard'],
    },
    {
      title: isAr ? 'المجتمع' : 'Community',
      links: isAr ? ['مدوّنة', 'حالات نجاح', 'الميثاق', 'الحوكمة', 'تواصل'] : ['Blog', 'Case Studies', 'Charter', 'Governance', 'Contact'],
    },
    {
      title: isAr ? 'مفتوح المصدر' : 'Open Source',
      links: isAr ? ['جيتهب', 'الترخيص', 'المساهمة', 'الأمان', 'وثائق'] : ['GitHub', 'License (MIT)', 'Contributing', 'Security', 'Docs'],
    },
  ];
  return (
    <footer className="footer">
      <div className="wrap">
        <div className="footer__grid">
          <div className="footer__brand">
            <a className="logo" href="#">
              <span className="logo__mark"><H_IShield size={22} /></span>
              <span className="logo__txt">
                <span className="logo__name">{isAr ? 'وقف' : 'Waqf'}</span>
                <span className="logo__eye">{isAr ? 'مفتوح المصدر' : 'Open Source'}</span>
              </span>
            </a>
            <p>
              {isAr
                ? 'مجتمع مفتوح المصدر يبني التقنية للأمة الإسلامية — كل التزام صدقة جارية.'
                : 'Open-source community building tech for the Muslim Ummah. Every commit, a Sadaqah Jariyah.'}
              <span className="ar">صدقة جارية عبر الكود</span>
            </p>
          </div>
          {groups.map((g, i) => (
            <div key={i}>
              <h4 className="footer__title">{g.title}</h4>
              <ul className="footer__list">
                {g.links.map((l, j) => <li key={j}><a href="#">{l}</a></li>)}
              </ul>
            </div>
          ))}
        </div>

        <div className="footer__bottom">
          <span>© 2026 Waqf Platform · MIT License</span>
          <span className="footer__made">
            {isAr ? 'صُنع بـ' : 'Made with'} <H_IHeartFilled size={14} /> {isAr ? 'للأمة' : 'for the Ummah'}
          </span>
          <span className="footer__social">
            <a href="#" aria-label="GitHub"><H_IGithub size={16} /></a>
            <a href="#" aria-label="Twitter"><H_ITwitter size={16} /></a>
            <a href="#" aria-label="Discord"><H_IDiscord size={16} /></a>
            <a href="#" aria-label="Email"><H_IMail size={16} /></a>
          </span>
        </div>
      </div>
    </footer>
  );
}

window.Ticker = Ticker;
window.Stats = Stats;
window.Mission = Mission;
window.HowItWorks = HowItWorks;
window.FeaturedProjects = FeaturedProjects;
window.Categories = Categories;
window.DualPath = DualPath;
window.Voices = Voices;
window.CtaBlock = CtaBlock;
window.Footer = Footer;
