# Waqf Design System

> **Tech for the Ummah — صدقة جارية عبر الكود**
>
> Design system for the **Waqf platform**, an open-source community where Muslim developers contribute code as *Sadaqah Jariyah* (ongoing charity). Every commit is framed as an act of worship that earns *Hasanat* (rewards) for as long as it continues to benefit the Ummah.

## Sources

This system was built by reading the canonical Waqf source repository:

- **GitHub**: [SalehAlobaylan/Waqf-Platform](https://github.com/SalehAlobaylan/Waqf-Platform) — Next.js 16 app, single source of truth
  - `src/app/globals.css` — Tailwind v4 `@theme` block, all design tokens
  - `src/components/landing/LandingPage.tsx` — hero, stats, categories, testimonials, CTA
  - `src/components/layout/Navbar.tsx` — header / logo / nav
  - `Plans/Waqf Platform Figma/` — exported Figma-to-code reference (shadcn UI primitives, Header, ExplorePage, ProjectDetailPage, ProfilePage)
  - `messages/en.json` + `messages/ar.json` — full bilingual copy in `next-intl` format
  - `Plans/Implementation_Roadmap.md` — product scope + PRD anchors

Readers with access to that repo can explore further — the LandingPage component (38 KB) and the Figma Plans folder (69 files of shadcn-style UI primitives) are the richest references for visual fidelity. Components in `Plans/Waqf Platform Figma/src/components/ui/` are vanilla shadcn — anything not redefined here defaults to that vocabulary.

---

## What is Waqf?

A *waqf* (وقف) is an Islamic endowment — wealth dedicated permanently to public benefit. The product extends that idea to code: developers donate skills to open-source Islamic projects (Quran APIs, Zakat calculators, Islamic EdTech, halal finance tools) and the codebase becomes a perpetual charity.

**Two roles:**
- **Contributor** (مساهم) — finds projects matching their skills, applies, contributes code.
- **Creator** (منشئ) — lists open-source projects, recruits volunteers, manages applications.

**Core surfaces:**
- Landing (marketing) → Explore (browse + filter) → Project Detail → Apply Modal → Dashboard → Messages → Profile → Admin

---

## Visual identity at a glance

| | |
|---|---|
| **Primary** | `#1f705d` — Waqf Green. Calm, mosque-roof-tile green. Used on logo, primary CTAs, links, all "trust" surfaces. |
| **Accent**  | `#d4a056` — Hasanat Gold. Reserved for **reward**, **featured**, **beta**, and ratings — never structural. |
| **Surface** | `#f9fbfb` app background on `#e9f1ef` mint-tinted borders. Subtle, paper-like. |
| **Type**    | Inter (LTR) + Noto Sans Arabic (RTL). Headlines run *very* heavy — `font-weight: 900` (black) with tight tracking `-0.033em`. |
| **Shape**   | Generous radii — buttons `rounded-xl` (16px), cards `rounded-2xl` (24px), CTA section `rounded-3xl` (32px). Pills used for badges. |
| **Logo**    | Material shield silhouette (protection / guardianship metaphor) in a 10% green tile. Always paired with the eyebrow **OPEN SOURCE** in caps tracking. |

---

## Content fundamentals

### Voice & tone

Confident, sincere, mission-driven. The product is bilingual at its core — every string ships in both English and Arabic, and the brand expects both to coexist in the same view (the hero literally stacks English headline + Arabic subhead).

- **Sentence case** for body copy and most UI strings.
- **Title Case** for navigation, buttons, section headers (`Start Contributing`, `Explore Domains`, `Featured Projects`).
- **UPPERCASE** sparingly — only on eyebrow labels (`OPEN SOURCE`, `BETA AVAILABLE`) with very wide tracking.
- **You/your** when addressing the contributor. The product talks *to* the developer, not at them.
- **We** when speaking as the platform. Rare.
- No exclamation marks except in success toasts (`Application accepted!`).

### Vocabulary — Islamic terms used unitalicised, untranslated

These are first-class brand words. Don't translate or italicise them.

- **Sadaqah Jariyah** — ongoing charity. The product's whole proposition.
- **Hasanat** — rewards / good deeds.
- **Ummah** — the global Muslim community.
- **Zakat** — obligatory annual charity.
- **Waqf / Waqif / Mutawalli** — endowment / endower / trustee. Roles within the platform.
- **Dhikr, Adhkar, Salah, Masjid** — appear in project names and categories.

### Bilingual rules

- **English copy is title-cased and concise.** Hero: `Tech for the Ummah`.
- **Arabic copy is set in Noto Sans Arabic** and often poeticised: `صدقة جارية عبر الكود` (literally "ongoing charity through code") is the brand's signature line.
- **Both languages share the same layout.** RTL flips with `dir="rtl"` on `<html>`; the font family swaps automatically (see `colors_and_type.css`).
- **Never mix Latin headlines with Arabic body text in the same run** — stack them as two distinct elements, each in their native font.

### Tone examples (verbatim from the repo)

| Surface | Copy |
|---|---|
| Hero subtitle | "Join the first open-source community building technology for the Muslim Ummah. Contribute your skills to projects that benefit millions—Sadaqah Jariyah through code." |
| How-it-works step 3 | "Benefit from Sadaqah Jariyah as your code serves the community continuously." |
| Final CTA | "Ready to code for a cause?" / "Join thousands of developers turning their commits into Sadaqah Jariyah." |
| Stat label | "Zero Platform Fees" |
| Footer signoff | "Made with ❤️ for the Ummah" |
| Onboarding | "How would you like to use the platform? Choose your primary path now (you can always switch roles later)." |

### Emoji

**Rarely.** A single ❤️ in the footer signoff and the social-proof "Made with ❤️ for the Ummah" string. The Figma exploration also uses emoji icons (📖 🤝 🕌 💰) on project category tiles in the Explore page — but the production codebase replaces these with Lucide icons (`BookOpen`, `HandHeart`, `GraduationCap`, `PiggyBank`). **Prefer Lucide; use emoji only as an Explore-page accent.**

---

## Visual foundations

### Colors

Three palettes — primary (green), accent (gold), secondary (slate) — each in 50→950 steps. Plus four Waqf-specific tokens:

- `--waqf-bg: #f9fbfb` — app background, slightly warmer than pure white
- `--waqf-border: #e9f1ef` — *the* default border colour. Used everywhere — cards, dividers, inputs.
- `--waqf-muted: #588d81` — desaturated teal for secondary text on green-tinted sections (e.g. filter icons in the sidebar)
- `--waqf-ink: #101917` — near-black for all headings

**Gold (`#d4a056`) is reward-coded.** It never carries information or structure. Use it only for:
- Featured badges (`Beta Available`, `Reward`)
- Star ratings
- The 3rd "Earn Hasanat" step in How-It-Works
- Hover ambient glow on accent CTAs

**Per-category accent tints** appear on the Explore page (blue / orange / teal / pink / cyan / emerald — all at `~10% opacity` background + matching `~600` text). These are tints, not brand colours; treat them as data viz palette.

### Typography

- **Hero**: `text-4xl md:text-5xl lg:text-6xl`, `font-black` (900), `tracking-[-0.033em]`, `leading-[1.1]`. The English line is followed by an Arabic line in a slightly smaller size — `text-4xl md:text-5xl lg:text-6xl` but explicitly tagged with `font-family: 'Noto Sans Arabic'`.
- **Section heads**: `text-3xl`/`text-4xl`, `font-bold` or `font-black`, `tracking-tight`.
- **Card titles**: `text-lg`, `font-bold`.
- **Body**: `text-base` or `text-lg`, normal weight, `text-gray-600`, `leading-relaxed`.
- **Eyebrows**: `text-xs` or `text-[10px]`, `font-bold`, `uppercase`, `tracking-widest`. Always coloured primary or accent — never grey.
- **Stat numbers**: `text-3xl`, `font-black`, `tracking-tight`, *near-black ink*. Often paired with a tiny Lucide icon inline.

### Spacing & layout

- Container is **`max-w-[1280px]`** everywhere. Don't grow wider.
- Page horizontal padding: `px-4` mobile → `px-10` desktop.
- Section vertical rhythm: `py-16 md:py-24` for marketing sections, `py-8` for utility strips (stats).
- Grids: marketing uses 1/2/3/4-column responsive grids with `gap-6` to `gap-12`.

### Backgrounds & textures

- **App background**: flat `#f9fbfb` — *not* white.
- **Hero**: same flat colour + a CSS texture overlay — `transparenttextures.com/patterns/clean-gray-paper.png` (very subtle paper grain). Don't use noisy patterns; this one is whisper-quiet.
- **"How it works" section**: `bg-[#1f705d]/5` (primary at 5% opacity) with two **giant blurred orbs** in corners — `w-96 h-96 bg-[#1f705d]/5 rounded-full blur-3xl` and the same in accent gold. This is the signature ambient-light treatment.
- **Final CTA block**: solid `#1f705d` with a `radial-gradient(#fff 1px, transparent 1px)` dot pattern at 10% opacity on a 20px grid. The dot pattern is the brand's only repeating texture.
- **Featured project cards**: gradient placeholder `from-[#1f705d]/10 to-[#d4a056]/10` with a giant initial letter at `text-6xl font-black text-[#1f705d]/20` when no image. Photography uses Unsplash placeholders in the Figma reference — treat real imagery as warm, daylight, mosque/community-coded.

### Animation

Restrained. Three motion families:

1. **Hover lift** — buttons: `hover:translate-y-[-1px]`, cards: `hover:shadow-md` from `shadow-sm`.
2. **Icon micro-interactions** — `group-hover:scale-110` on category-tile icons; `transition-transform`.
3. **Decorative pulse / float** — only one instance in the entire codebase: the "Impact 1.2M Users reached" card in the hero has `animate-pulse` (production) or `animate-bounce` with `animationDuration: '3s'` (Figma reference). Use sparingly.

Default transition is `transition-all duration-300` or `transition-colors` — no bouncy springs, no rotates. The hero code-snippet card has a single playful exception: `rotate-[-2deg] hover:rotate-0 transition-transform duration-500`.

### Hover & press states

- **Primary button** (`bg-[#1f705d]`) → `hover:bg-[#165244]` (darker green) + 1px lift.
- **Secondary button** (`bg-white border border-gray-200`) → `hover:bg-gray-50`.
- **Ghost button / link** → `hover:text-[#1f705d]` from `text-[#101917]`.
- **Card** → `hover:shadow-lg` and `hover:border-[#1f705d]/50` (border tint becomes more primary).
- **Icon button** → `hover:bg-gray-100 rounded-lg` (subtle slate fill).
- **No press/active states defined** — rely on browser defaults. Add `active:scale-[0.98]` for new tactile components if needed.

### Borders, shadows, radii

- **Default border**: `1px solid #e9f1ef`. Use it as the universal card outline; everything sits on it.
- **Strong border** (rarely used): `border-gray-200` (≈ slate-200).
- **Radii**: never sharp. Smallest is `rounded-md` (10px) on inputs; cards are `rounded-xl` (16px) or `rounded-2xl` (24px); the final CTA block is `rounded-3xl` (32px). Pills (`rounded-full`) for badges and avatars.
- **Shadows**: a soft 3-tier system (`sm` / `md` / `lg` / `xl`) using slate-tinted alpha. Primary CTAs additionally carry a coloured glow — `shadow-lg shadow-[#1f705d]/25`. This is the **signature shadow** — green-tinted, never black.
- **Inner shadows**: not used.

### Transparency & blur

- **Sticky header**: `bg-[#f9fbfb]/95 backdrop-blur supports-[backdrop-filter]:bg-[#f9fbfb]/60`. Always with backdrop-blur.
- **Card on hero image**: `bg-white/80 backdrop-blur-md` for the rotated code-snippet card. The brand uses `/80` opacity + `backdrop-blur-md` whenever something floats over imagery.
- **Tint overlays**: ` bg-[#1f705d]/5` to `/10` for ambient backgrounds. Never `/20` or above — keeps everything airy.

### Cards

The canonical card:
```
className="bg-white p-6 rounded-2xl border border-[#e9f1ef]
           hover:border-[#1f705d]/50 hover:shadow-lg
           transition-all duration-300"
```

Image-topped cards use `rounded-xl overflow-hidden` (not 2xl, to keep image corners crisp) with the image area `h-48` and the body `p-6`.

### Fixed elements

- **Header**: `sticky top-0 z-50` with backdrop-blur. The *only* fixed element by default.
- **Filter sidebar** (Explore): `sticky top-[65px]` (header height), `h-[calc(100vh-65px)]`, internal scroll.

### Imagery vibe

When real photography appears (Unsplash references in the Figma file), it's:
- Warm-leaning daylight, never cool.
- Subjects: mosques, dashboards, code on screens, hands-on-keyboard, abstract architecture.
- Round avatar treatment: `w-8 h-8 rounded-full border-2 border-white` stacked in `-space-x-2` clusters for social-proof rows.

---

## Iconography

**Lucide React** is the canonical icon family across the entire production codebase. Every icon in `LandingPage.tsx`, `Navbar.tsx`, `ExplorePage.tsx`, `ProjectCard.tsx`, etc. is a Lucide import.

- Default stroke width: Lucide's default (~2px).
- Default size: `w-4 h-4` for inline text, `w-5 h-5` for buttons, `w-6 h-6` for category tiles, `w-10 h-10` for big How-It-Works circles.
- Coloured by parent `text-*` colour (almost always primary on hover or in tile contexts).
- Filled variants used on **stars** (`<Star fill="currentColor" />` in gold) and the **Heart** in step-3 of How-It-Works (`fill="currentColor"` in gold).

### Key icons in use

| Icon | Where |
|---|---|
| `Shield` (Material spec, custom path) | Logo mark |
| `Code` | "Start Contributing" CTA, code-snippet card |
| `Heart` | Sadaqah Jariyah / "Made with ❤️ for the Ummah" |
| `Search` | Search bars, "Discover" step |
| `BookOpen` | Quran & Sunnah category |
| `HandHeart` | Charity & Zakat category |
| `GraduationCap` | Islamic EdTech category |
| `PiggyBank` | Halal Finance category |
| `Globe` | Language switcher, Global Community |
| `Shield` (filled) | Open Source / trust strip |
| `Bell` | Notifications |
| `Folder`, `Users`, `GitCommit` | Stat row |
| `ArrowRight`, `ChevronLeft`, `ChevronRight`, `ChevronDown` | Navigation affordances |
| `CheckCircle` (filled) | Verified organisation badge |
| `Star` (filled) | Testimonial ratings |
| `Bookmark` | Save-project action on cards |

### Emoji as icons

Used **only** in the Figma exploration's Explore page mock — 📖 🤝 🕌 💰 📱 🌍 on category tiles. Production replaces these with Lucide. Don't introduce new emoji icons.

### SVG / custom assets

The repo's `public/` folder ships only the default Next.js placeholders (`file.svg`, `globe.svg`, `window.svg`, `vercel.svg`, `next.svg`) — none are actually used by the app. The only custom SVG is the **shield logo path** embedded inline in `Navbar.tsx`. See `assets/logo-mark.svg`, `assets/logo-lockup.svg`, and `assets/logo-arabic.svg` for extracted versions.

### Icon usage rules

1. Reach for **Lucide** first. Always.
2. Match colour to context: green on trust/primary, gold on reward, slate on neutral, blue/emerald/etc. only when paired with a per-category tint background.
3. Size by hierarchy: 16 / 20 / 24 / 40px. Don't introduce in-between sizes.
4. Filled icons are emotionally loaded — use only for hearts (Hasanat), stars (rating), and shields (verified). Everything else is outlined.

---

## File index

```
.
├── README.md                   ← you are here
├── SKILL.md                    ← Claude Skills entry point
├── colors_and_type.css         ← all design tokens (CSS vars) + semantic typography
├── fonts/
│   └── README.md               ← font sourcing notes (Inter, Noto Sans Arabic, JetBrains Mono — Google Fonts CDN)
├── assets/
│   ├── logo-mark.svg           ← shield, primary green
│   ├── logo-lockup.svg         ← shield + "Waqf" + OPEN SOURCE eyebrow
│   ├── logo-arabic.svg         ← shield + وقف + مفتوح المصدر
│   ├── icon-file.svg           ← Next.js default placeholders (kept for reference)
│   ├── icon-globe.svg
│   ├── icon-window.svg
│   └── favicon.ico
├── preview/                    ← Design System tab cards (auto-registered)
│   ├── colors-primary.html
│   ├── colors-accent.html
│   ├── colors-neutrals.html
│   ├── colors-semantic.html
│   ├── colors-categories.html
│   ├── type-scale.html
│   ├── type-headings.html
│   ├── type-arabic.html
│   ├── type-eyebrows.html
│   ├── radii-shadows.html
│   ├── spacing.html
│   ├── buttons.html
│   ├── inputs.html
│   ├── badges.html
│   ├── cards.html
│   ├── stat-row.html
│   ├── logo-lockup.html
│   └── icon-grid.html
└── ui_kits/
    └── waqf-web/               ← web (Next.js) UI kit
        ├── README.md
        ├── index.html          ← click-through prototype
        ├── Navbar.jsx
        ├── HeroSection.jsx
        ├── StatRow.jsx
        ├── CategoryGrid.jsx
        ├── HowItWorks.jsx
        ├── ProjectCard.jsx
        ├── ExploreView.jsx
        ├── ProjectDetailView.jsx
        ├── ApplyModal.jsx
        ├── CtaBlock.jsx
        ├── Footer.jsx
        └── primitives.jsx      ← Button, Badge, Input, Card
```

---

## CAVEATS

- **No bespoke brand illustrations exist** in the source repo. Hero imagery is either a stylised inline code card OR an Unsplash placeholder. Treat full-bleed photography as TBD.
- **Font files are loaded via Google Fonts CDN at runtime.** No `.woff2`/`.ttf` files are committed in this design system — `fonts/README.md` documents how to self-host if needed.
- **The shield logo is a Material-Icons stock path** ("shield" filled). It's used inline; no separate logo PDF/SVG exists in the source. The extracted lockups in `assets/` are reconstructions.
- The **Figma file referenced as "Waqf Platform Figma"** is the exported React/shadcn code in `Plans/Waqf Platform Figma/` — there is no live Figma link in the repo.
- The Explore page emoji icons (📖 🤝 🕌) appear only in the **Figma exploration**; the production codebase uses Lucide equivalents. This system documents both but prefers Lucide.
