# Fonts

The Waqf platform uses **system fonts loaded from Google Fonts at runtime** — there are no font files committed in the source repo (it relies on Tailwind v4 `@import "tailwindcss"` and references font families by name only).

## Stack

| Family | Use | Weights | Source |
|---|---|---|---|
| **Inter** | Latin / English (LTR default) | 400, 500, 600, 700, 800, 900 | [Google Fonts](https://fonts.google.com/specimen/Inter) |
| **Noto Sans Arabic** | Arabic (RTL default) | 400, 500, 600, 700, 800, 900 | [Google Fonts](https://fonts.google.com/specimen/Noto+Sans+Arabic) |
| **JetBrains Mono** | Code snippets in hero illustration | 400, 500, 600 | [Google Fonts](https://fonts.google.com/specimen/JetBrains+Mono) |

These are imported via the `@import url(...)` line at the top of `../colors_and_type.css`. No `.ttf`/`.woff2` files need to live in this folder unless you want offline / self-hosted builds.

## Local self-hosting (optional)

If you want to commit the actual font files, download the woff2 files from Google Fonts → "Download family" and drop them in this folder, then replace the `@import` line in `colors_and_type.css` with `@font-face` declarations pointing to `./fonts/...`.
