---
name: waqf-design
description: Use this skill to generate well-branded interfaces and assets for Waqf — the open-source Islamic developer platform where every commit is framed as Sadaqah Jariyah. Contains essential design guidelines, colors (Waqf green + Hasanat gold), type (Inter + Noto Sans Arabic), Lucide icon usage, brand assets, and a complete React UI kit for the web product.
user-invocable: true
---

# Waqf Design Skill

Read the **`README.md`** at the root of this skill first — it covers the full brand context: company background, content fundamentals (voice/tone, bilingual rules, Islamic vocabulary), visual foundations (colors, type, spacing, motion, hover/press), and iconography (Lucide-first).

Then explore the other available files:

- **`colors_and_type.css`** — all design tokens as CSS custom properties. Import this at the top of any artifact you build.
- **`assets/`** — extracted logo lockups (`logo-mark.svg`, `logo-lockup.svg`, `logo-arabic.svg`) + favicon. Copy these out as needed; never re-draw the shield mark from scratch.
- **`fonts/README.md`** — Inter + Noto Sans Arabic + JetBrains Mono are loaded from Google Fonts via the `@import` at the top of `colors_and_type.css`. No local files unless you self-host.
- **`preview/`** — every design token visualised in a small HTML card (colors, type, spacing, components, brand). Open any of these to see the system in use.
- **`ui_kits/waqf-web/`** — production-style React recreation of the web product. Pixel-faithful Navbar, Hero, ExploreView, ProjectDetailView, ApplyModal, etc. **Lift components from here rather than rebuilding.**

## How to behave when invoked

If creating **visual artifacts** (slides, mocks, throwaway prototypes, marketing pages, screen mockups):
1. Copy the assets you need out of `assets/` into your output folder.
2. Reference (or inline) `colors_and_type.css` so the design tokens are available.
3. Lift components from `ui_kits/waqf-web/` — the Navbar, ProjectCard, Hero, CTA block, and Footer are all reusable. Don't redraw them.
4. Output a static HTML file the user can open and review.

If working on **production code**:
1. Read the rules in `README.md` (especially Content fundamentals, Visual foundations, Iconography) until you can name the four design tokens unprompted.
2. Reuse the kit's class vocabulary (`wq-btn`, `wq-card--feature`, `wq-pill--accent`, etc.) where possible.
3. Use Lucide React for icons — never inline SVG, never emoji as iconography.
4. Respect the bilingual contract: every user-facing string must work in both English (Inter) and Arabic (Noto Sans Arabic) without layout break.

## If invoked with no specific brief

Ask the user a short set of questions:

1. **What surface are you designing?** (marketing page · onboarding · admin · dashboard · slide deck · email · other)
2. **English, Arabic, or both?** Waqf is bilingual by default.
3. **Do you want a single direction or a few variations to compare?**
4. **Are there specific components or screens already in play?** (the web kit covers landing, explore, project detail, apply modal, auth shell — flag if you need something outside this set)
5. **Tone:** standard brand voice, or a specific moment? (launch announcement, condolence post, Ramadan campaign, etc.)

Then act as an expert Waqf-brand designer. Default to HTML artifacts unless the user asks for production code.

## Don'ts

- ❌ **Don't introduce new emoji** as iconography. Stick to Lucide. The only emoji in the brand is ❤️ in `Made with ❤️ for the Ummah`.
- ❌ **Don't use gold (`#d4a056`) as structure.** It's reward-coded — featured badges, ratings, the Hasanat step. Never a primary CTA.
- ❌ **Don't draw new logo marks.** Use `assets/logo-mark.svg`.
- ❌ **Don't shorten radii.** Buttons are 12px, cards 16–24px, the final CTA block 32px. The brand reads soft.
- ❌ **Don't transliterate the Islamic vocabulary.** *Sadaqah Jariyah*, *Hasanat*, *Ummah*, *Zakat*, *Waqf* — keep them as-is, untranslated, unitalicised.

## Signature phrases

- "Tech for the Ummah"
- "صدقة جارية عبر الكود" *(Sadaqah Jariyah through code)*
- "Ready to code for a cause?"
- "Made with ❤️ for the Ummah"
