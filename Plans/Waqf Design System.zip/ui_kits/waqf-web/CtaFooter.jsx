function FeaturedProjects({ onNavigate }) {
  const featured = window.WAQF_PROJECTS.slice(0, 3);
  return (
    <section className="wq-section" style={{ background: 'var(--waqf-bg)' }}>
      <div className="wq-container">
        <div className="wq-section__head wq-section__head--row">
          <h2 className="wq-section__title">Featured Projects</h2>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="wq-nav__iconbtn" style={{ width: 40, height: 40, borderRadius: 999, border: '1px solid var(--secondary-200)' }}><IconChevronLeft size={18} /></button>
            <button className="wq-nav__iconbtn" style={{ width: 40, height: 40, borderRadius: 999, border: '1px solid var(--secondary-200)' }}><IconChevronRight size={18} /></button>
          </div>
        </div>
        <div className="wq-cats" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))' }}>
          {featured.map(p => (
            <ProjectCard key={p.id} project={p} onClick={() => onNavigate('detail', { id: p.id })} />
          ))}
        </div>
      </div>
    </section>
  );
}

function CtaBlock({ onNavigate }) {
  return (
    <section className="wq-cta">
      <div className="wq-container">
        <div className="wq-cta__box">
          <div className="wq-cta__inner">
            <h2 className="wq-cta__title">Ready to code for a cause?</h2>
            <p className="wq-cta__lede">Join thousands of developers turning their commits into Sadaqah Jariyah.</p>
            <div className="wq-cta__btns">
              <Button variant="ondark-primary" size="lg" onClick={() => onNavigate('signup')}>Sign Up Now</Button>
              <Button variant="ondark-secondary" size="lg" onClick={() => onNavigate('explore')}>Explore Projects</Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="wq-footer">
      <div className="wq-container">
        <div className="wq-footer__grid">
          <div>
            <div className="wq-logo">
              <span className="wq-logo__mark"><IconShieldFilled /></span>
              <span className="wq-logo__word">
                <span className="wq-logo__name">Waqf</span>
              </span>
            </div>
            <p className="wq-footer__brand-desc">Building the digital future of the Ummah, one commit at a time.</p>
          </div>
          <div>
            <h4 className="wq-footer__title">Platform</h4>
            <ul className="wq-footer__list">
              <li><a>Explore Projects</a></li><li><a>How it Works</a></li>
              <li><a>Pricing</a></li><li><a>Leaderboard</a></li>
            </ul>
          </div>
          <div>
            <h4 className="wq-footer__title">Community</h4>
            <ul className="wq-footer__list">
              <li><a>Guidelines</a></li><li><a>Discord</a></li>
              <li><a>Blog</a></li><li><a>Events</a></li>
            </ul>
          </div>
          <div>
            <h4 className="wq-footer__title">Legal</h4>
            <ul className="wq-footer__list">
              <li><a>Privacy Policy</a></li><li><a>Terms of Service</a></li>
              <li><a>Cookie Policy</a></li>
            </ul>
          </div>
        </div>
        <div className="wq-footer__bottom">
          <span>© 2026 Waqf Platform. All rights reserved.</span>
          <span className="wq-footer__made">Made with <IconHeart filled size={14} /> for the Ummah</span>
        </div>
      </div>
    </footer>
  );
}

Object.assign(window, { FeaturedProjects, CtaBlock, Footer });
