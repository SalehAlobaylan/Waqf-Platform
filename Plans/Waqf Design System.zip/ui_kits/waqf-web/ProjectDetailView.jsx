function ProjectDetailView({ projectId, onNavigate, onApply }) {
  const project = window.WAQF_PROJECTS.find(p => p.id === projectId) || window.WAQF_PROJECTS[0];

  return (
    <div className="wq-detail">
      <div className="wq-detail__breadcrumb">
        <a onClick={() => onNavigate('landing')}>Home</a>
        <span>›</span>
        <a onClick={() => onNavigate('explore')}>Projects</a>
        <span>›</span>
        <span style={{ color: 'var(--fg-2)' }}>{project.name}</span>
      </div>

      <div className="wq-detail__hero">
        <div className="wq-detail__row">
          <IconTile icon={<span style={{ fontSize: 28, fontWeight: 900 }}>{project.initial}</span>} tone={project.tone} size="lg" />
          <div className="wq-detail__id">
            <h1 className="wq-detail__title">{project.name}</h1>
            <p className="wq-detail__org">
              by {project.organization}
              {project.verified ? <span className="wq-project__verified" title="Verified"><IconCheckCircle size={14} /></span> : null}
            </p>
            <div className="wq-detail__badges">
              <Badge tone={'impact-' + project.impact.tone}>
                <span style={{ marginRight: 4 }}>{project.impact.icon}</span>{project.impact.label}
              </Badge>
              {project.skills.map(s => <Badge key={s} tone={project.skillTones?.[s] || 'neutral'}>{s}</Badge>)}
            </div>
          </div>
          <div className="wq-detail__actions">
            <button className="wq-nav__iconbtn" style={{ border: '1px solid var(--secondary-200)', borderRadius: 10 }}><IconBookmark size={18} /></button>
            <Button variant="secondary" size="lg" icon={<IconGitHub size={18} />}>View on GitHub</Button>
            <Button variant="primary" size="lg" icon={<IconHeart size={18} />} onClick={onApply}>Apply to Contribute</Button>
          </div>
        </div>

        <p className="wq-detail__lede" style={{ marginTop: 24 }}>
          {project.longDescription || project.description}
        </p>
      </div>

      <div className="wq-detail__panel">
        <h3>At a glance</h3>
        <div className="wq-detail__meta">
          <div className="wq-detail__meta-item">
            <div className="lbl">Status</div>
            <div className="val"><span className="wq-project__status-dot" style={{ background: '#10b981' }}></span>Open</div>
          </div>
          <div className="wq-detail__meta-item">
            <div className="lbl">Commitment</div>
            <div className="val">{project.commitment}</div>
          </div>
          <div className="wq-detail__meta-item">
            <div className="lbl">Contributors</div>
            <div className="val"><IconUsers size={14} />{project.contributors}</div>
          </div>
          <div className="wq-detail__meta-item">
            <div className="lbl">License</div>
            <div className="val">{project.license}</div>
          </div>
        </div>
      </div>

      <div className="wq-detail__panel">
        <h3>How you can help</h3>
        <ul style={{ margin: 0, padding: '0 0 0 20px', color: 'var(--fg-2)', fontSize: 14, lineHeight: 1.7 }}>
          <li>Optimize Postgres full-text search for Arabic morphology and diacritics.</li>
          <li>Add typed SDKs (Python &amp; Go) and publish to PyPI / pkg.go.dev.</li>
          <li>Improve audio streaming for low-bandwidth regions.</li>
          <li>Translate the developer documentation into Urdu and French.</li>
        </ul>
      </div>

      <div className="wq-detail__panel" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 16, flexWrap: 'wrap' }}>
        <div>
          <h3 style={{ margin: 0 }}>Ready to contribute?</h3>
          <p style={{ margin: '4px 0 0 0', color: 'var(--fg-3)', fontSize: 13 }}>The maintainer is notified the moment you apply.</p>
        </div>
        <Button variant="primary" size="lg" icon={<IconHeart size={18} />} onClick={onApply}>Apply to Contribute</Button>
      </div>
    </div>
  );
}

function ApplyModal({ project, onClose }) {
  const [why, setWhy] = useState('');
  const [hours, setHours] = useState('');
  const [submitted, setSubmitted] = useState(false);

  if (!project) return null;

  return (
    <div className="wq-modal-bd" onClick={onClose}>
      <div className="wq-modal" onClick={(e) => e.stopPropagation()}>
        <div className="wq-modal__head">
          <div>
            <h2 className="wq-modal__title">{submitted ? 'Application sent ✓' : 'Apply to Contribute'}</h2>
            <p className="wq-modal__sub">{submitted ? "We've notified the maintainer." : `Project · ${project.name}`}</p>
          </div>
          <button className="wq-modal__close" onClick={onClose}><IconClose size={20} /></button>
        </div>

        {submitted ? (
          <div className="wq-modal__body" style={{ alignItems: 'center', textAlign: 'center', padding: '8px 24px 32px' }}>
            <div className="wq-tile wq-tile--lg wq-tile--primary" style={{ margin: '8px 0 12px' }}>
              <IconHeart filled size={28} />
            </div>
            <p style={{ margin: 0, color: 'var(--fg-2)', fontSize: 15 }}>
              The team at <b>{project.organization}</b> will review your application and reach out via the in-app messaging system.
            </p>
            <p style={{ margin: '12px 0 0 0', color: 'var(--accent-600)', fontWeight: 700, fontSize: 14 }}>
              May Allah accept this from you. <span style={{ fontFamily: 'var(--font-arabic)' }}>تقبل الله منكم</span>
            </p>
            <Button variant="primary" size="md" onClick={onClose} style={{ marginTop: 16 }}>Back to project</Button>
          </div>
        ) : (
          <>
            <div className="wq-modal__body">
              <div className="wq-field">
                <label>Why do you want to contribute?</label>
                <textarea className="wq-textarea" placeholder="Share your motivation and how you can help this project…" value={why} onChange={(e) => setWhy(e.target.value)} />
                <p className="hint">Mention your relevant experience and what draws you to this project.</p>
              </div>
              <div className="wq-field">
                <label>Portfolio or GitHub</label>
                <Input placeholder="https://github.com/your-handle" />
              </div>
              <div className="wq-field">
                <label>Hours available per week</label>
                <div className="wq-select-wrap">
                  <select className="wq-select" value={hours} onChange={(e) => setHours(e.target.value)}>
                    <option value="">Select availability</option>
                    <option>&lt; 2 hours</option><option>2–5 hours</option>
                    <option>5–10 hours</option><option>10+ hours</option>
                  </select>
                  <IconChevronDown size={16} />
                </div>
              </div>
            </div>
            <div className="wq-modal__foot">
              <span className="wq-modal__note">Project owners will be notified of your application.</span>
              <div style={{ display: 'flex', gap: 8 }}>
                <Button variant="secondary" size="md" onClick={onClose}>Cancel</Button>
                <Button variant="primary" size="md" onClick={() => setSubmitted(true)}>Submit Application</Button>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

Object.assign(window, { ProjectDetailView, ApplyModal });
