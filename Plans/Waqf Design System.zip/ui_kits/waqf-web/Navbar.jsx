function Navbar({ currentPage, onNavigate, locale = 'en' }) {
  const isAr = locale === 'ar';
  return (
    <header className="wq-nav">
      <div className="wq-container">
        <div className="wq-nav__inner">
          <div className="wq-logo" onClick={() => onNavigate('landing')}>
            <span className="wq-logo__mark"><IconShieldFilled /></span>
            <span className="wq-logo__word">
              <span className="wq-logo__name" style={isAr ? { fontFamily: 'var(--font-arabic)' } : null}>
                {isAr ? 'وقف' : 'Waqf'}
              </span>
              <span className="wq-logo__eye">{isAr ? 'مفتوح المصدر' : 'Open Source'}</span>
            </span>
          </div>

          <nav className="wq-nav__links">
            <span className={'wq-nav__link' + (currentPage === 'explore' ? ' wq-nav__link--active' : '')} onClick={() => onNavigate('explore')}>{isAr ? 'استكشف' : 'Explore'}</span>
            <span className="wq-nav__link" onClick={() => onNavigate('howitworks')}>{isAr ? 'كيف يعمل' : 'How it Works'}</span>
            <span className="wq-nav__link">{isAr ? 'حول' : 'About'}</span>
          </nav>

          <div className="wq-nav__actions">
            <button className="wq-nav__lang" onClick={() => onNavigate(currentPage, { locale: isAr ? 'en' : 'ar' })}>
              <IconGlobe size={14} /> {isAr ? 'EN' : 'AR'}
            </button>
            <span className="wq-nav__divider"></span>
            <button className="wq-nav__iconbtn" title="Notifications">
              <IconBell size={20} />
              <span className="wq-nav__bell-dot"></span>
            </button>
            <Button variant="ghost" size="md" onClick={() => onNavigate('login')}>{isAr ? 'تسجيل دخول' : 'Log In'}</Button>
            <Button variant="primary" size="md" onClick={() => onNavigate('signup')}>{isAr ? 'تسجيل' : 'Sign Up'}</Button>
          </div>
        </div>
      </div>
    </header>
  );
}
window.Navbar = Navbar;
