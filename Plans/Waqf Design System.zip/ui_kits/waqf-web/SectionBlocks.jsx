function StatRow({ locale = 'en' }) {
  const isAr = locale === 'ar';
  const stats = [
    { num: '150+',   label: isAr ? 'مشاريع نشطة' : 'Active Projects',     icon: <IconFolder size={20} /> },
    { num: '2,000+', label: isAr ? 'مساهمين'      : 'Contributors',        icon: <IconUsers size={20} /> },
    { num: '10k+',   label: isAr ? 'مساهمات'      : 'Commits for Good',    icon: <IconGitCommit size={20} /> },
    { num: isAr ? 'صفر' : 'Zero', label: isAr ? 'رسوم المنصة' : 'Platform Fees' },
  ];
  return (
    <section className="wq-stats">
      <div className="wq-container">
        <div className="wq-stats__grid">
          {stats.map((s, i) => (
            <div className="wq-stats__item" key={i}>
              <div className="wq-stats__num">{s.icon}{s.num}</div>
              <div className="wq-stats__label">{s.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function CategoryGrid({ onNavigate, locale = 'en' }) {
  const isAr = locale === 'ar';
  const cats = [
    { tone: 'primary', icon: <IconBookOpen size={24} />,  en: { t: 'Quran & Sunnah', d: 'APIs, reading apps, and memorization tools.' },     ar: { t: 'القرآن والسنة',   d: 'واجهات برمجية، تطبيقات قراءة، وأدوات حفظ.' } },
    { tone: 'accent',  icon: <IconHandHeart size={24} />, en: { t: 'Charity & Zakat', d: 'Donation platforms, Zakat calculators, aid tracking.' }, ar: { t: 'الزكاة والصدقات', d: 'منصات تبرع، حاسبات زكاة، وتتبع المساعدات.' } },
    { tone: 'blue',    icon: <IconGradCap size={24} />,   en: { t: 'Islamic EdTech',  d: 'LMS for Madrasahs, Arabic learning, kids apps.' },    ar: { t: 'التعليم الإسلامي', d: 'أنظمة تعليم للمدارس، تعلم العربية، تطبيقات أطفال.' } },
    { tone: 'emerald', icon: <IconPiggyBank size={24} />, en: { t: 'Halal Finance',   d: 'Ethical investment tools, inheritance calculators.' }, ar: { t: 'المالية الإسلامية', d: 'أدوات استثمار أخلاقية، حاسبات الميراث.' } },
  ];
  return (
    <section className="wq-section">
      <div className="wq-container">
        <div className="wq-section__head wq-section__head--row">
          <div>
            <h2 className="wq-section__title">{isAr ? 'استكشف المجالات' : 'Explore Domains'}</h2>
            <p className="wq-section__sub">{isAr ? 'اكتشف المشاريع في مختلف القطاعات التي تحتاج خبرتك.' : 'Discover projects across various sectors needing your expertise.'}</p>
          </div>
          <Button variant="link" icon={<IconArrowRight size={16} />} onClick={() => onNavigate('explore')}>
            {isAr ? 'عرض جميع الفئات' : 'View All Categories'}
          </Button>
        </div>
        <div className="wq-cats">
          {cats.map((c, i) => {
            const copy = isAr ? c.ar : c.en;
            return (
              <Card key={i} className="wq-card--feature wq-card--clickable" onClick={() => onNavigate('explore')}>
                <IconTile icon={c.icon} tone={c.tone} size="md" />
                <h3 className="wq-cat-title">{copy.t}</h3>
                <p className="wq-cat-desc">{copy.d}</p>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}

function HowItWorks({ locale = 'en' }) {
  const isAr = locale === 'ar';
  const steps = [
    { icon: <IconSearch />, t: isAr ? '1. اكتشف' : '1. Discover',     d: isAr ? 'اعثر على مشاريع مفتوحة المصدر تناسب مهاراتك واهتماماتك.' : 'Find open-source projects that match your tech stack and interests.' },
    { icon: <IconCode />,   t: isAr ? '2. ساهم'   : '2. Contribute',   d: isAr ? 'أرسل طلبات سحب، أصلح الأخطاء، أو أضف ميزات لتحسين الكود.' : 'Submit pull requests, fix bugs, or add features to improve the codebase.' },
    { icon: <IconHeart filled />, t: isAr ? '3. اكسب الحسنات' : '3. Earn Hasanat', d: isAr ? 'استفد من الصدقة الجارية كلما خدم كودك المجتمع باستمرار.' : 'Benefit from Sadaqah Jariyah as your code serves the community continuously.', reward: true },
  ];
  return (
    <section className="wq-section wq-section--tint">
      <div className="wq-container">
        <div className="wq-section__head wq-section__head--centered">
          <h2 className="wq-section__title">{isAr ? 'كيف يعمل' : 'How It Works'}</h2>
          <p className="wq-section__sub" style={{ textAlign: 'center', margin: '0 auto' }}>
            {isAr ? 'رحلتك من كتابة الكود إلى الأجر المستمر.' : 'Your journey from code commit to eternal reward.'}
          </p>
        </div>
        <div className="wq-steps">
          {steps.map((s, i) => (
            <div className="wq-step" key={i}>
              <div className={'wq-step__circle ' + (s.reward ? 'wq-step__circle--reward' : '')}>
                <div className={'wq-tile wq-tile--xl' + (s.reward ? ' wq-tile--xl-accent' : '')}>{s.icon}</div>
                {s.reward ? <Pill tone="reward">{isAr ? 'مكافأة' : 'Reward'}</Pill> : null}
              </div>
              <h3 className="wq-step__title">{s.t}</h3>
              <p className="wq-step__desc">{s.d}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

Object.assign(window, { StatRow, CategoryGrid, HowItWorks });
