function App() {
  const [page, setPage] = useState('landing');         // landing | explore | detail | login | signup
  const [locale, setLocale] = useState('en');
  const [activeProjectId, setActiveProjectId] = useState(null);
  const [applyOpen, setApplyOpen] = useState(false);

  const navigate = (next, opts) => {
    if (opts && opts.locale) { setLocale(opts.locale); return; }
    if (next === 'detail' && opts && opts.id) setActiveProjectId(opts.id);
    setPage(next);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const activeProject = window.WAQF_PROJECTS.find(p => p.id === activeProjectId);

  return (
    <div data-locale={locale}>
      <Navbar currentPage={page} onNavigate={navigate} locale={locale} />

      {page === 'landing' ? (
        <>
          <HeroSection onNavigate={navigate} locale={locale} />
          <StatRow locale={locale} />
          <CategoryGrid onNavigate={navigate} locale={locale} />
          <HowItWorks locale={locale} />
          <FeaturedProjects onNavigate={navigate} />
          <CtaBlock onNavigate={navigate} />
          <Footer />
        </>
      ) : null}

      {page === 'explore' ? (
        <>
          <ExploreView onNavigate={navigate} />
          <Footer />
        </>
      ) : null}

      {page === 'detail' ? (
        <>
          <ProjectDetailView projectId={activeProjectId} onNavigate={navigate} onApply={() => setApplyOpen(true)} />
          <Footer />
        </>
      ) : null}

      {(page === 'login' || page === 'signup') ? (
        <div style={{ minHeight: 'calc(100vh - 65px)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24 }}>
          <Card className="wq-card--feature" style={{ width: '100%', maxWidth: 440 }}>
            <Eyebrow tone="primary">{page === 'login' ? 'Welcome Back' : 'Create Your Account'}</Eyebrow>
            <h2 className="wq-section__title" style={{ fontSize: 28, marginTop: 8 }}>
              {page === 'login' ? 'Sign in to continue' : 'Join the Ummah'}
            </h2>
            <p style={{ color: 'var(--fg-3)', fontSize: 13, margin: '4px 0 24px 0' }}>
              {page === 'login' ? 'Continue your journey of Sadaqah Jariyah.' : 'Sign up to contribute to Islamic open-source projects.'}
            </p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              <Button variant="secondary" size="lg" icon={<IconGitHub size={18} />}>Continue with GitHub</Button>
              <div style={{ textAlign: 'center', color: 'var(--fg-4)', fontSize: 12, margin: '4px 0' }}>or continue with email</div>
              {page === 'signup' ? <Input placeholder="Full name" /> : null}
              <Input placeholder="Email address" type="email" />
              <Input placeholder="Password" type="password" />
              <Button variant="primary" size="lg" onClick={() => navigate('landing')}>
                {page === 'login' ? 'Sign In' : 'Create Account'}
              </Button>
              <p style={{ textAlign: 'center', color: 'var(--fg-3)', fontSize: 13, margin: '8px 0 0 0' }}>
                {page === 'login' ? (
                  <>Don't have an account? <a style={{ color: 'var(--primary-600)', fontWeight: 700, cursor: 'pointer' }} onClick={() => navigate('signup')}>Sign up</a></>
                ) : (
                  <>Already have an account? <a style={{ color: 'var(--primary-600)', fontWeight: 700, cursor: 'pointer' }} onClick={() => navigate('login')}>Sign in</a></>
                )}
              </p>
            </div>
          </Card>
        </div>
      ) : null}

      {applyOpen ? <ApplyModal project={activeProject} onClose={() => setApplyOpen(false)} /> : null}
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
