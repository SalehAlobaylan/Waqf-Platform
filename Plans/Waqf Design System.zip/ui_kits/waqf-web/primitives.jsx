// Shared UI primitives — Button, Badge, Card, Input, Pill, Eyebrow, IconTile
const { useState } = React;

function Button({ variant = 'primary', size = 'lg', icon, children, onClick, className = '', ...rest }) {
  const base = 'wq-btn wq-btn--' + variant + ' wq-btn--' + size + ' ' + className;
  return (
    <button className={base.trim()} onClick={onClick} {...rest}>
      {icon ? <span className="wq-btn__icon">{icon}</span> : null}
      <span>{children}</span>
    </button>
  );
}

function Badge({ children, tone = 'neutral', className = '' }) {
  return <span className={'wq-badge wq-badge--' + tone + ' ' + className}>{children}</span>;
}

function Pill({ children, tone = 'primary', dot = false }) {
  return (
    <span className={'wq-pill wq-pill--' + tone}>
      {dot ? <span className="wq-pill__dot"/> : null}
      {children}
    </span>
  );
}

function Eyebrow({ children, tone = 'primary' }) {
  return <span className={'wq-eyebrow wq-eyebrow--' + tone}>{children}</span>;
}

function IconTile({ icon, tone = 'primary', size = 'md' }) {
  return <div className={'wq-tile wq-tile--' + tone + ' wq-tile--' + size}>{icon}</div>;
}

function Card({ children, className = '', onClick, style }) {
  return (
    <div className={'wq-card ' + className} onClick={onClick} style={style}>{children}</div>
  );
}

function Input({ icon, ...rest }) {
  return (
    <div className={'wq-input-wrap' + (icon ? ' wq-input-wrap--icon' : '')}>
      {icon ? <span className="wq-input__icon">{icon}</span> : null}
      <input className="wq-input" {...rest} />
    </div>
  );
}

function Checkbox({ checked, onChange, label }) {
  return (
    <label className="wq-check">
      <input type="checkbox" checked={checked} onChange={onChange}/>
      <span>{label}</span>
    </label>
  );
}

function Avatar({ initials, size = 32, tone = 'primary' }) {
  return (
    <div className={'wq-avatar wq-avatar--' + tone} style={{ width: size, height: size, fontSize: size * 0.4 }}>
      {initials}
    </div>
  );
}

Object.assign(window, { Button, Badge, Pill, Eyebrow, IconTile, Card, Input, Checkbox, Avatar });
