function FilterSidebar({ filters, setFilters }) {
  const cats   = ['Quran Apps', 'Charity & Zakat', 'Islamic EdTech', 'Halal Finance', 'Prayer'];
  const skills = ['React / Next.js', 'Python', 'Flutter', 'Go', 'Kotlin'];
  const types  = ['Verified Organization', 'Community Driven'];

  const toggle = (key, val) => {
    const cur = filters[key] || [];
    setFilters({ ...filters, [key]: cur.includes(val) ? cur.filter(x => x !== val) : [...cur, val] });
  };

  return (
    <aside className="wq-sidebar">
      <div className="wq-sidebar__head">
        <h2 className="wq-sidebar__title">Filters</h2>
        <button className="wq-sidebar__clear" onClick={() => setFilters({ cats: [], skills: [], types: [] })}>Clear All</button>
      </div>

      <div className="wq-filter-group">
        <h3 className="wq-filter-group__title"><IconPackage size={16} />Category</h3>
        <div className="wq-filter-group__list">
          {cats.map(c => (
            <Checkbox key={c} label={c}
              checked={(filters.cats || []).includes(c)}
              onChange={() => toggle('cats', c)} />
          ))}
        </div>
      </div>

      <div className="wq-filter-group">
        <h3 className="wq-filter-group__title"><IconCode size={16} />Skills</h3>
        <div className="wq-filter-group__list">
          {skills.map(s => (
            <Checkbox key={s} label={s}
              checked={(filters.skills || []).includes(s)}
              onChange={() => toggle('skills', s)} />
          ))}
        </div>
      </div>

      <div className="wq-filter-group">
        <h3 className="wq-filter-group__title"><IconGlobe size={16} />Project Type</h3>
        <div className="wq-filter-group__list">
          {types.map(t => (
            <Checkbox key={t} label={t}
              checked={(filters.types || []).includes(t)}
              onChange={() => toggle('types', t)} />
          ))}
        </div>
      </div>

      <div className="wq-filter-group">
        <h3 className="wq-filter-group__title"><IconCalendar size={16} />Commitment</h3>
        <div className="wq-filter-group__list">
          <Checkbox label="< 2 hrs/week" onChange={() => {}} />
          <Checkbox label="5–10 hrs/week" onChange={() => {}} />
          <Checkbox label="One-time task" onChange={() => {}} />
        </div>
      </div>
    </aside>
  );
}

function ExploreView({ onNavigate }) {
  const [query, setQuery] = useState('');
  const [filters, setFilters] = useState({ cats: ['Charity & Zakat'], skills: [], types: ['Verified Organization'] });
  const all = window.WAQF_PROJECTS;
  const filtered = all.filter(p => !query || p.name.toLowerCase().includes(query.toLowerCase()) || p.description.toLowerCase().includes(query.toLowerCase()));

  return (
    <div className="wq-explore">
      <FilterSidebar filters={filters} setFilters={setFilters} />
      <main className="wq-explore__main">
        <div className="wq-explore__head">
          <div>
            <h1 className="wq-explore__title">Explore Opportunities</h1>
            <p className="wq-explore__sub">Find a project to contribute your skills for Sadaqah Jariyah.</p>
          </div>
          <Pill tone="primary" dot>{filtered.length} Active Projects</Pill>
        </div>

        <div className="wq-explore__toolbar">
          <Input icon={<IconSearch size={18} />}
            value={query} onChange={(e) => setQuery(e.target.value)}
            placeholder="Search projects by name, technology, or impact…" />
          <div className="wq-select-wrap">
            <select className="wq-select">
              <option>Recommended</option><option>Newest First</option>
              <option>Most Active</option><option>Expiring Soon</option>
            </select>
            <IconChevronDown size={16} />
          </div>
          <Button variant="secondary" size="lg" icon={<IconFilter size={16} />} className="wq-explore__mobile-filter">Filters</Button>
        </div>

        <div className="wq-explore__grid">
          {filtered.map(p => (
            <ProjectCard key={p.id} project={p} onClick={() => onNavigate('detail', { id: p.id })} />
          ))}
        </div>

        <div style={{ marginTop: 48, display: 'flex', justifyContent: 'center' }}>
          <Button variant="secondary" size="lg" icon={<IconChevronDown size={18} />}>Load More Projects</Button>
        </div>
      </main>
    </div>
  );
}

window.ExploreView = ExploreView;
