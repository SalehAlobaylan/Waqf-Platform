# Waqf · Web UI Kit

A modular React (Babel-transpiled inline JSX) recreation of the **Waqf platform** — the open-source Islamic developer community where every commit is *Sadaqah Jariyah*.

This kit is a **visual + interaction recreation** of the production app at [`SalehAlobaylan/Waqf-Platform`](https://github.com/SalehAlobaylan/Waqf-Platform). It cuts corners on functionality (no auth, no API, no real DB) but reproduces the visual language, component vocabulary, and click-through flow faithfully.

## What's in here

| File | Purpose |
|---|---|
| `index.html` | Entry — boots React + Babel and mounts `<App />` |
| `kit.css` | All component styles, scoped with `wq-` prefix. Imports `colors_and_type.css` from the system root. |
| `icons.jsx` | Inline Lucide-style SVG icons — `IconShield`, `IconHeart`, `IconCode`, etc. No CDN. |
| `primitives.jsx` | `Button`, `Badge`, `Pill`, `Eyebrow`, `IconTile`, `Card`, `Input`, `Checkbox`, `Avatar` |
| `mockData.jsx` | `WAQF_PROJECTS` — six seed projects matching the Figma Explore mock |
| `Navbar.jsx` | Sticky top nav, logo lockup, language toggle, bell, log-in / sign-up |
| `HeroSection.jsx` | Hero with bilingual headline, beta pill, code-snippet card, impact badge |
| `SectionBlocks.jsx` | `StatRow`, `CategoryGrid`, `HowItWorks` |
| `ProjectCard.jsx` | Reusable project card — used on landing, explore, and elsewhere |
| `CtaFooter.jsx` | `FeaturedProjects`, `CtaBlock`, `Footer` |
| `ExploreView.jsx` | Sidebar filters + search + sort + project grid |
| `ProjectDetailView.jsx` | Single project page + `ApplyModal` |
| `App.jsx` | Router shell — landing / explore / detail / login / signup + apply modal |

## Click-through flow

The prototype is fully interactive — open `index.html` and you'll land on the marketing page. From there you can:

1. **Landing** → click *Start Contributing* → **Explore**.
2. **Explore** → toggle category / skill filters, search, then click any project card → **Detail**.
3. **Detail** → click *Apply to Contribute* → **Apply Modal** → submit → success state.
4. **Navbar** → *Log In* / *Sign Up* swap in a centered card layout.
5. **Navbar AR/EN toggle** → flips the landing hero, nav, and stat row between English and Arabic.

## Component conventions

- Every component exports onto `window` (no module bundler). New files in this kit must end with `Object.assign(window, { ... })` or `window.X = X`.
- CSS classes are all prefixed `wq-` to avoid collision with any host app.
- Icons take a `size` prop (default 20) and inherit `currentColor`.
- Buttons take `variant` (`primary` / `secondary` / `ghost` / `ondark-primary` / `ondark-secondary` / `link`) + `size` (`lg` / `md` / `sm`) + optional `icon`.
- All hover affordances follow the brand rules in the root `README.md` — primary lifts by 1px, cards gain `shadow-lg`, etc.

## What's intentionally NOT in here

- **Auth flows** — login/signup show the visual shell but don't validate.
- **Form validation** — only the required-field hint pattern is documented; no zod / yup.
- **Notifications dropdown panel, messaging, dashboard, profile, admin** — out of scope for this first kit. Add them as siblings to `ExploreView.jsx` following the same conventions.
- **Server data** — everything reads from `WAQF_PROJECTS` in `mockData.jsx`.

## Extending

To add a new screen:

1. Build a `MyView.jsx` exporting `window.MyView = MyView`.
2. Add a `<script type="text/babel" data-presets="react" src="MyView.jsx">` to `index.html` **after** any dependencies (e.g. after `primitives.jsx`).
3. Add a route case to `App.jsx`'s page switch.

Styles for new components live in `kit.css` under their own clearly-labelled section. Reuse design tokens from `colors_and_type.css` — never hard-code hex values.
