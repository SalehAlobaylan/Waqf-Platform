function ProjectCard({ project, onClick }) {
  const tone = project.tone || 'primary';
  const statusDot = { open: '#10b981', active: '#f59e0b', closed: '#cbd5e1' }[project.status] || '#cbd5e1';
  return (
    <Card className="wq-card--project wq-card--clickable wq-project" onClick={onClick}>
      <div className="wq-project__head">
        <div className="wq-project__id">
          <IconTile icon={<span style={{ fontSize: 22, fontWeight: 900 }}>{project.initial}</span>} tone={tone} size="md" />
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <h3 className="wq-project__name">{project.name}</h3>
              {project.verified ? (
                <span className="wq-project__verified" title="Verified Organization">
                  <IconCheckCircle size={16} />
                </span>
              ) : null}
            </div>
            <p className="wq-project__org">by {project.organization}</p>
          </div>
        </div>
        <button className="wq-project__bookmark" onClick={(e) => e.stopPropagation()}>
          <IconBookmark size={18} />
        </button>
      </div>
      <div className="wq-project__body">
        <Badge tone={'impact-' + project.impact.tone}>
          <span style={{ marginRight: 4 }}>{project.impact.icon}</span>{project.impact.label}
        </Badge>
        <p className="wq-project__desc">{project.description}</p>
        <div className="wq-project__skills">
          {project.skills.map(s => (
            <Badge key={s} tone={project.skillTones?.[s] || 'neutral'}>{s}</Badge>
          ))}
        </div>
      </div>
      <div className="wq-project__foot">
        <span className="wq-project__status">
          <span className="wq-project__status-dot" style={{ background: statusDot }} />
          Active {project.lastActive}
        </span>
        <Button variant="primary" size="sm" onClick={(e) => { e.stopPropagation(); onClick && onClick(); }}>Contribute</Button>
      </div>
    </Card>
  );
}
window.ProjectCard = ProjectCard;
