function HeroSection({ onNavigate, locale = 'en' }) {
  const isAr = locale === 'ar';
  return (
    <section className="wq-hero">
      <div className="wq-container">
        <div className="wq-hero__grid">
          <div>
            <Pill tone="accent" dot>{isAr ? 'نسخة تجريبية' : 'Beta Available'}</Pill>
            <h1 className="wq-hero__title" style={{ marginTop: 16 }}>
              {isAr
                ? <span className="wq-hero__title-green" style={{ fontFamily: 'var(--font-arabic)' }}>صدقة جارية عبر الكود</span>
                : <>Tech for the Ummah<span className="wq-hero__title-ar">صدقة جارية عبر الكود</span></>}
            </h1>
            <p className="wq-hero__lede">
              {isAr
                ? 'انضم إلى أول مجتمع مفتوح المصدر يبني التقنية للأمة الإسلامية. ساهم بمهاراتك في مشاريع تفيد الملايين—صدقة جارية من خلال الكود.'
                : 'Join the first open-source community building technology for the Muslim Ummah. Contribute your skills to projects that benefit millions—Sadaqah Jariyah through code.'}
            </p>
            <div className="wq-hero__ctas">
              <Button variant="primary" icon={<IconCode size={20} />} onClick={() => onNavigate('explore')}>
                {isAr ? 'ابدأ المساهمة' : 'Start Contributing'}
              </Button>
              <Button variant="secondary" icon={<span style={{ fontSize: 22, lineHeight: 1 }}>+</span>}>
                {isAr ? 'أضف مشروعاً' : 'List a Project'}
              </Button>
            </div>
            <div className="wq-hero__proof">
              <div className="wq-hero__proof-avatars">
                <Avatar initials="A" tone="primary" />
                <Avatar initials="M" tone="accent" />
                <Avatar initials="S" tone="blue" />
                <Avatar initials="+2k" tone="slate" />
              </div>
              <p style={{ margin: 0 }}>{isAr ? 'انضم إلى 2,000+ مساهم حول العالم' : 'Join 2,000+ contributors worldwide'}</p>
            </div>
          </div>

          <div className="wq-hero__visual">
            <div className="wq-snippet">
              <div className="wq-snippet__bar">
                <div className="wq-snippet__dots">
                  <span style={{ background: '#f87171' }} />
                  <span style={{ background: '#fbbf24' }} />
                  <span style={{ background: '#4ade80' }} />
                </div>
                <span className="wq-snippet__filename">contribute.js</span>
              </div>
              <div className="wq-snippet__code">
                <div>
                  <span style={{ color: '#8b5cf6' }}>const</span>{' '}
                  <span style={{ color: '#3b82f6' }}>sadaqah</span>{' '}
                  <span style={{ color: '#94a3b8' }}>=</span>{' '}
                  <span style={{ color: '#d4a056' }}>async</span>
                  <span style={{ color: '#94a3b8' }}>{'() =>'}</span>{' '}
                  <span style={{ color: '#94a3b8' }}>{'{'}</span>
                </div>
                <div className="indent">
                  <span style={{ color: '#8b5cf6' }}>await</span>{' '}
                  <span style={{ color: '#3b82f6' }}>buildForUmmah</span>
                  <span style={{ color: '#94a3b8' }}>();</span>
                </div>
                <div className="indent">
                  <span style={{ color: '#8b5cf6' }}>return</span>{' '}
                  <span style={{ color: '#10b981' }}>"Hasanat++"</span>
                  <span style={{ color: '#94a3b8' }}>;</span>
                </div>
                <div><span style={{ color: '#94a3b8' }}>{'}'}</span></div>
              </div>
              <div className="wq-impact-badge">
                <IconHeart filled size={18} />
                <div>
                  <div className="wq-impact-badge__label">{isAr ? 'التأثير' : 'Impact'}</div>
                  <div className="wq-impact-badge__value">{isAr ? '1.2M مستخدم' : '1.2M Users reached'}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
window.HeroSection = HeroSection;
